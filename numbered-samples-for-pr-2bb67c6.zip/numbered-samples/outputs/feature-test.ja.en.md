---
title: ファイル翻訳の機能テスト（Markdown）
tags: [テスト, 翻訳]
---

# 【M02 Heading 1】Functional Testing of File Translation

【M03 Paragraphs and Soft Line Breaks】This paragraph is written across two lines, but it will appear as a single paragraph when displayed.

【M04 Strong Line Break】There are two spaces at the end of this line.  
This line will be wrapped within the same paragraph. A backslash at the end of the line will also cause a line break.\
This line is also part of the same paragraph.

## 【M02 Heading 2】Text Formatting

【M05 Emphasis】This text contains **bold**, *italics*, and ~~strikethroughs~~.

【M06 Inline Code】Do not change the names of the configuration file `settings.json` or the command `cargo test`.

### 【M02 Heading 3】Links and Images

【M07 Link】For details, please refer to the [Terms of Use page](https://example.com/terms "利用規約").

【M08 Reference Link】The procedure is described in the [Getting Started Guide][guide].

【M09 Automatic Link】Contact information is <https://example.com/support>.

![【M10 Alternative Text】Diagram showing the flow from the original to the translation](feature-test-image.png)

[guide]: https://example.com/guide "導入の手引き"

## 【M02 Heading 2】List

- 【M11 Bulleted List】Level 1 Items
- Second item of the first level
  - Second-level item
  - Second item of the second level
- The last item ends in sentence form.

1. 【M12 Numbered List】Step One
2. Step Two
3. The third step

- [x] 【M13 Task List】Completed Work
- [ ] Work not yet completed

## 【M02 Heading 2】Table

【M14 Table】The following table specifies left-aligned, centered, and right-aligned alignment for each column.

| item | deadline | amount |
| :--- | :---: | ---: |
| transportation expenses | April 1, 2027 | 5,000 yen |
| accommodation expenses | April 15, 2027 | 12,000 yen |
| **Total** | | 17,000 yen |

## 【M02 Heading 2】Code and Quotations

【M15 Code Block】Comments in the following code will remain untranslated.

```python
# 設定を読み込む（このコメントは翻訳されない）
config = load("settings.json")
```

> 【M16 Quote】This is a quoted paragraph. There is also **bold text** within the quote.

## 【M02 Heading 2】HTML and Special Syntax

<div class="note">
【M17 HTML ブロック】この HTML の中の文章は翻訳されず、確認箇所に行番号が表示されます。
</div>

【M18 インライン HTML】保存するには <kbd>Ctrl</kbd> + <kbd>S</kbd> を押してください。

【M19 Formula】The area of a circle is found using $S = \pi r^2$.

【M20 Footnote】This text has a footnote.[^note]

[^note]: 【M20 Footnote Text】This is the footnote text.

---

【M21 Horizon】The line above is the horizon.

【M22 記号のエスケープ】C++ と C# は言語の名前です。1\. のように書くと番号付きリストになりません。\*印\* は強調ではありません。

## 【M02 Heading 2】Confirmation of Meaning

【M23 Figures, Dates, and Amounts】Effective April 1, 2027, the maximum amount per case will be changed to 50,000 yen. The annual budget is 120 million yen, which is 8% less than the previous fiscal year.

【M24 Negation/Conditions】Applications will not be accepted without the department head's approval. However, this shall not apply in cases of urgency.
