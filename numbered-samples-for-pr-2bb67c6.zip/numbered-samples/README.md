# File translation verification at `2bb67c6`

Built and ran the release app on Apple Silicon macOS using PLaMo 3 Translate 2B Q4_K_M on Metal. Opened the original numbered fixtures through the Files tab, translated from Japanese to English, saved separate files, and reopened the exports from disk. The four results were still listed after restarting the app.

| Format | Opened the exported file with | Spot check |
| --- | --- | --- |
| TXT | TextEdit | T10 kept April 1, 2027, ¥50,000, ¥120 million, and 8%. T11 kept the approval requirement and emergency exception. |
| Markdown | TextEdit | M22 on source line 88 was identical in the export on line 86, including its Japanese text and escapes. Nearby M21 and M23 were translated. |
| DOCX | Microsoft Word | The translated file opened in Compatibility Mode. In D07, only “only this part” remained bold. |
| PPTX | Microsoft PowerPoint | The translated file opened and displayed P12. The merged cell and blank cell were retained. The English title wrapped, and the amounts and dates remained intact. |

The fixture checklist lists the available reference points. This run spot-checked the items above. The PPTX before/after image was rendered separately with LibreOffice.

## Files

| Format | Input | Export |
| --- | --- | --- |
| TXT | [Japanese input](inputs/feature-test.ja.txt) | [English export](outputs/feature-test.ja.en.txt) |
| MD | [Japanese input](inputs/feature-test.ja.md) | [English export](outputs/feature-test.ja.en.md) |
| DOCX | [Japanese input](inputs/feature-test.ja.docx) | [English export](outputs/feature-test.ja.en.docx) |
| PPTX | [Japanese input](inputs/feature-test.ja.pptx) | [English export](outputs/feature-test.ja.en.pptx) |

## Screenshots

- [DOCX export reopened in Microsoft Word](screenshots/docx-reopened-in-word.jpg)
- [DOCX translation completed with review locations expanded](screenshots/docx-review.jpg)
- [Native Save As dialog](screenshots/docx-save-dialog.jpg)
- [DOCX saved with Open translation available](screenshots/docx-saved.jpg)
- [Files tab after restart with all four completed translations](screenshots/history-after-restart.jpg)
- [M22 retained in the saved Markdown](screenshots/markdown-m22-in-textedit.jpg)
- [Markdown export reopened in TextEdit](screenshots/markdown-reopened-in-textedit.jpg)
- [Markdown export completed](screenshots/markdown-result.jpg)
- [PPTX translation in progress](screenshots/pptx-progress.jpg)
- [PPTX loaded and ready to translate](screenshots/pptx-ready.jpg)
- [PPTX export reopened on slide P12 in Microsoft PowerPoint](screenshots/pptx-reopened-in-powerpoint.jpg)
- [PPTX review locations and layout guidance](screenshots/pptx-review.jpg)
- [PPTX export completed](screenshots/pptx-saved.jpg)
- [TXT export reopened in TextEdit](screenshots/txt-reopened-in-textedit.jpg)
- [TXT export completed](screenshots/txt-result.jpg)

[P12 before and after](pr-assets/P12-table-before-after.png)
